// background/sidepanel-controller.js — 사이드 패널 진입점 5종 공통 헬퍼
// 진입점: icon / context / shortcut / popup / float (docs/DESIGN.md 6장)

import { BGLogger } from './logger.js' ;
import { PANEL_SOURCES } from '../shared/messages.js' ;

let lastOpenAt = 0 ;

export async function openSidePanel(source) {
  if (!PANEL_SOURCES.includes(source)) {
    BGLogger.warn('PANEL', `알 수 없는 진입점 source=${source}`) ;
    source = 'icon' ;
  }
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }) ;
    if (!tab) {
      BGLogger.warn('PANEL', '활성 탭 없음') ;
      return { ok: false, error: { code: 'E-CHR-UI-1001', message: '사이드 패널을 열 수 없습니다.' } } ;
    }
    // 연속 호출 방지 (1초 내 중복)
    const now = Date.now() ;
    if (now - lastOpenAt < 1000) {
      BGLogger.debug('PANEL', '연속 호출 무시 (debounce)') ;
      return { ok: true } ;
    }
    lastOpenAt = now ;
    await chrome.sidePanel.open({ windowId: tab.windowId }) ;
    BGLogger.feature('PANEL', `사이드 패널 열림 source=${source}`) ;
    return { ok: true } ;
  } catch (e) {
    BGLogger.error('PANEL', `사이드 패널 열기 실패 (${e.message})`) ;
    return { ok: false, error: { code: 'E-CHR-UI-1001', message: '사이드 패널을 열 수 없습니다. 다시 시도해 주세요.' } } ;
  }
}