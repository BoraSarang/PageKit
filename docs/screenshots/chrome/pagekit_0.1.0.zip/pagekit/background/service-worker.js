// background/service-worker.js — PageKit MV3 백그라운드 서비스 워커 (진입점)

import { BGLogger } from './logger.js' ;
import { DebugLogger } from '../debug-module.js' ;
import { openSidePanel } from './sidepanel-controller.js' ;
import { MSG, msgOk, msgErr } from '../shared/messages.js' ;
import * as storage from './storage.js' ;
import { initDownloader } from './downloader.js' ;
import { initStreamDetector } from './stream-detector.js' ;

const RUN_SCRIPTS = [
  'debug.js',
  'node_modules/@mozilla/readability/Readability.js',
  'content/unlock.js',
  'content/extractor.js',
  'content/highlight.js',
  'content/float-button.js',
] ;

// 이미 주입된 스크립트 추적 (탭 단위로는 chrome.storage.session 사용)
async function ensureInjected(tabId) {
  const key = `injected:${tabId}` ;
  const injected = await storage.getSession(key, false) ;
  if (injected) return true ;
  await chrome.scripting.executeScript({
    target: { tabId },
    files: RUN_SCRIPTS,
  }) ;
  await storage.setSession(key, true) ;
  return true ;
}

async function injectFloatButton(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ['debug.js', 'content/float-button.js'],
  }) ;
  await chrome.scripting.insertCSS({
    target: { tabId },
    files: ['content/float-button.css'],
  }) ;
}

// --- 디버그 창 관리 (AGENTS.md 19장, Shop WiseBar 참고) ---
let _debugWinId = null ;

function openDebugWindow() {
  const url = chrome.runtime.getURL('debug-view.html') ;
  if (_debugWinId != null) {
    chrome.windows.update(_debugWinId, { focused: true }, () => {
      if (chrome.runtime.lastError) _debugWinId = null ;
    }) ;
    return ;
  }
  chrome.windows.create({ url, type: 'popup', width: 900, height: 640 }, (win) => {
    if (chrome.runtime.lastError || !win) return ;
    _debugWinId = win.id ;
    chrome.windows.onRemoved.addListener((removedId) => {
      if (removedId === _debugWinId) _debugWinId = null ;
    }) ;
  }) ;
  BGLogger.feature('BG', '디버그 창 열림') ;
}

// --- 설치/시작 시 초기화 ---
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'pk-analyze',
      title: 'PageKit으로 분석',
      contexts: ['page', 'selection', 'image', 'video', 'link'],
    }) ;
    chrome.contextMenus.create({
      id: 'pk-debug',
      title: 'PageKit 디버그 창 열기',
      contexts: ['action'],
    }) ;
  }) ;
  BGLogger.feature('BG', '확장 설치/업데이트 초기화 완료 (컨텍스트 메뉴 등록)') ;
}) ;

initDownloader() ;
initStreamDetector() ;

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'pk-analyze') {
    (async () => {
      await ensureInjected(tab.id) ;
      await openSidePanel('context') ;
    })() ;
  } else if (info.menuItemId === 'pk-debug') {
    openDebugWindow() ;
  }
}) ;

// --- 키보드 단축키 (진입점 ③ + 디버그) ---
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'pagekit-open-panel') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }) ;
    if (tab?.id != null) await ensureInjected(tab.id) ;
    await openSidePanel('shortcut') ;
  } else if (command === 'pagekit-toggle-debug') {
    openDebugWindow() ;
  }
}) ;

// --- 메시지 라우팅 ---
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== 'string') return false ;
  const tabId = sender.tab?.id ;
  const tabUrl = sender.tab?.url ;

  switch (message.type) {
    // content 스크립트 로그 위임 → debugEnabled 확인 후 중앙 기록
    case 'DEBUG_LOG': {
      chrome.storage.local.get('debugEnabled', (v) => {
        if (!(v && v.debugEnabled)) return ;
        const entry = message.entry || {} ;
        if (tabId != null) entry.tabId = tabId ;
        if (tabUrl) entry.url = tabUrl ;
        chrome.storage.local.get('debugLog', (cur) => {
          let arr = Array.isArray(cur && cur.debugLog) ? cur.debugLog : [] ;
          arr = arr.concat([entry]).slice(-2000) ;
          chrome.storage.local.set({ debugLog: arr }) ;
        }) ;
      }) ;
      return false ;
    }
    case MSG.ENSURE_INJECTED: {
      if (tabId == null) {
        sendResponse(msgErr('E-CHR-PERM-1001', '활성 탭이 없습니다.')) ;
        return false ;
      }
      ensureInjected(tabId)
        .then(() => sendResponse(msgOk()))
        .catch((e) => {
          BGLogger.error('BG', `주입 실패 tab=${tabId}: ${e.message}`, { code: 'E-CHR-PERM-1001' }) ;
          sendResponse(msgErr('E-CHR-PERM-1001', '권한이 없어 스크립트를 주입할 수 없습니다.')) ;
        }) ;
      return true ;
    }
    case MSG.OPEN_SIDE_PANEL: {
      openSidePanel(message.source || 'popup').then(sendResponse) ;
      return true ;
    }
    case MSG.FLOAT_BUTTON_READY: {
      BGLogger.debug('FLOAT', `플로팅 버튼 준비됨 tab=${tabId}`) ;
      sendResponse(msgOk()) ;
      return false ;
    }
    case MSG.SETTINGS_GET: {
      storage.getSettings().then((s) => sendResponse(msgOk(s))) ;
      return true ;
    }
    case MSG.SETTINGS_SET: {
      storage.setSettings(message.payload || {}).then((s) => {
        BGLogger.info('SETTINGS', '설정 저장됨', s) ;
        sendResponse(msgOk(s)) ;
      }) ;
      return true ;
    }
    default:
      return false ;
  }
}) ;

chrome.runtime.onStartup.addListener(() => {
  BGLogger.info('BG', '브라우저 시작 감지') ;
}) ;

BGLogger.feature('BG', 'PageKit 백그라운드 서비스 워커 기동 완료') ;