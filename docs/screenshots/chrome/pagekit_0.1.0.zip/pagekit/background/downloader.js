// background/downloader.js — 배치 다운로드 + 상태 추적 (T-23/T-24)
// chrome.downloads 사용, 동시 N건, 실패 시 재시도 2회, 상태는 storage.session에 기록.

import { BGLogger } from './logger.js' ;
import * as storage from './storage.js' ;

const MAX_RETRY = 2 ;
let jobSeq = 0 ;
let running = [] ; // [{ jobId, item, retry, downloadId }]

function domainFrom(url) {
  try { return new URL(url).hostname.replace(/^www\./, '') || 'page' ; } catch { return 'page' ; }
}

function safeName(url, idx) {
  try {
    const u = new URL(url) ;
    const base = u.pathname.split('/').filter(Boolean).pop() || `file_${idx}` ;
    return decodeURIComponent(base).replace(/[\\/:*?"<>|]/g, '_') ;
  } catch { return `file_${idx}` ; }
}

function categoryOf(item) {
  return item.cat === 'images' ? 'images' : item.cat === 'videos' ? 'videos' : item.cat === 'audios' ? 'audios' : item.cat === 'streams' ? 'streams' : 'links' ;
}

function extOf(url) {
  const m = url.split('?')[0].match(/\.([a-z0-9]{1,6})$/i) ;
  return m ? `.${m[1].toLowerCase()}` : '' ;
}

async function persist() {
  await storage.setSession('downloadJobs', running) ;
}

function broadcast() {
  chrome.runtime.sendMessage({ type: 'pk.dl.progress', payload: running.map((j) => ({
    jobId: j.jobId, name: j.name, folder: j.folder, state: j.state, progress: j.progress,
  })) }).catch(() => {}) ;
  chrome.action.setBadgeText({ text: running.filter((j) => j.state === 'active').length ? String(running.filter((j) => j.state === 'active').length) : '' }).catch(() => {}) ;
}

async function startJob(item) {
  const job = {
    jobId: `job_${++jobSeq}`,
    item,
    name: item.filename || safeName(item.url, jobSeq),
    folder: domainFrom(item.url),
    state: 'active',
    progress: 0,
    retry: 0,
    downloadId: null,
  } ;
  running.push(job) ;
  await persist() ;
  broadcast() ;
  await runDownload(job) ;
}

async function runDownload(job) {
  const settings = await storage.getSettings() ;
  try {
    const name = job.name ;
    const needsExt = extOf(job.item.url) && !/\.(png|jpe?g|gif|webp|avif|mp4|webm|mp3|m4a|zip|pdf)$/i.test(name) ;
    const filename = `PageKit/${job.folder}/${categoryOf(job.item)}/${name}${needsExt ? extOf(job.item.url) : ''}` ;
    const downloadId = await chrome.downloads.download({
      url: job.item.url,
      filename,
      conflictAction: 'uniquify',
    }) ;
    job.downloadId = downloadId ;
    job.state = 'active' ;
    await persist() ;
    broadcast() ;
  } catch (e) {
    BGLogger.error('DL', `다운로드 시작 실패 ${job.item.url} (${e.message})`) ;
    await handleFail(job) ;
  }
}

async function handleFail(job) {
  if (job.retry < MAX_RETRY) {
    job.retry += 1 ;
    job.state = 'active' ;
    BGLogger.warn('DL', `재시도 ${job.retry}/${MAX_RETRY} ${job.name}`) ;
    await runDownload(job) ;
  } else {
    job.state = 'failed' ;
    await persist() ;
    broadcast() ;
    BGLogger.error('DL', `다운로드 실패 (${job.name})`, { code: 'E-CHR-DL-1002' }) ;
  }
}

function removeJob(jobId) {
  running = running.filter((j) => j.jobId !== jobId) ;
  persist() ;
  broadcast() ;
}

export function initDownloader() {
  chrome.downloads.onChanged.addListener(async (delta) => {
    const job = running.find((j) => j.downloadId === delta.id) ;
    if (!job) return ;

    if (delta.state) {
      if (delta.state.current === 'complete') {
        job.state = 'complete' ;
        job.progress = 100 ;
        BGLogger.info('DL', `완료: ${job.name}`) ;
        await persist() ;
        broadcast() ;
        // 완료 후 약간 지연 제거
        setTimeout(() => removeJob(job.jobId), 8000) ;
      } else if (delta.state.current === 'interrupted') {
        BGLogger.warn('DL', `중단: ${job.name} (${delta.error?.current || 'unknown'})`) ;
        await handleFail(job) ;
      }
    }
    if (delta.bytesReceived) {
      const total = job.item.size || 0 ;
      job.progress = total > 0 ? Math.min(99, Math.round((delta.bytesReceived.current / total) * 100)) : job.progress ;
    }
  }) ;

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === 'pk.dl.start') {
      const items = message.payload?.items || [] ;
      if (!items.length) {
        sendResponse({ ok: false, error: { code: 'E-CHR-DL-1001', message: '선택된 항목이 없습니다.' } }) ;
        return false ;
      }
      const settings = storage.getSettings().then((s) => {
        const queue = [...items] ;
        const workers = Math.min(s.concurrentDownloads || 3, 6) ;
        const run = async () => {
          while (queue.length) {
            const item = queue.shift() ;
            if (!item?.url?.startsWith('http')) continue ;
            await startJob(item) ;
            // 순차 진행 대기 (동시성은 상태상 병렬로 보이지만 chrome.downloads가 관리)
          }
        } ;
        Promise.all(Array.from({ length: workers }, run)).then(() => sendResponse({ ok: true, data: { started: items.length } })) ;
      }) ;
      return true ;
    }
    if (message?.type === 'pk.dl.state') {
      sendResponse({ ok: true, data: running.map((j) => ({
        jobId: j.jobId, name: j.name, folder: j.folder, state: j.state, progress: j.progress,
      })) }) ;
      return false ;
    }
    if (message?.type === 'pk.dl.cancel') {
      const job = running.find((j) => j.jobId === message.payload?.jobId) ;
      if (job?.downloadId != null) chrome.downloads.cancel(job.downloadId) ;
      removeJob(message.payload?.jobId) ;
      sendResponse({ ok: true }) ;
      return false ;
    }
    return false ;
  }) ;

  BGLogger.feature('BG', '다운로더 초기화 완료') ;
}