// content/extractor.js — 페이지 분석 실행 (F2/F3/F4)
// ANALYZE_PAGE 메시지 수신 → 본문(readability) + 미디어/링크 수집 → 결과 반환
// 주의: 원본 DOM 비파괴 (clone 사용), payload ≤1MB

(() => {
  if (globalThis.__pkExtractorLoaded) return ;
  globalThis.__pkExtractorLoaded = true ;

  const T0 = performance.now() ;

  // ---------- 안전한 sanitize (script/iframe/form 등 제거) ----------
  const FORBID_TAGS = new Set(['script', 'style', 'iframe', 'form', 'input', 'button', 'noscript']) ;
  const FORBID_ATTR = /^on|^style$/i ;

  function sanitize(root) {
    const stack = [root] ;
    while (stack.length) {
      const node = stack.pop() ;
      if (node.nodeType === Node.ELEMENT_NODE) {
        if (FORBID_TAGS.has(node.tagName.toLowerCase())) {
          node.remove() ;
          continue ;
        }
        for (const attr of [...node.attributes]) {
          if (FORBID_ATTR.test(attr.name)) node.removeAttribute(attr.name) ;
        }
        stack.push(...node.children) ;
      }
    }
    return root ;
  }

  // ---------- 본문 추출 (Readability, clone 기반) ----------
  function extractArticle() {
    const ReadabilityCtor = globalThis.Readability || (globalThis.Readability && globalThis.Readability.default) ;
    if (!ReadabilityCtor) return null ;
    const clone = document.cloneNode(true) ;
    sanitize(clone.documentElement) ;
    try {
      const reader = new ReadabilityCtor(clone, { charThreshold: 500, keepClasses: false }) ;
      return reader.parse() ;
    } catch (e) {
      return null ;
    }
  }

  // ---------- 본문 내 URL 집합 (inArticle 판정용) ----------
  function collectArticleUrls(articleHtml) {
    const container = document.createElement('div') ;
    container.innerHTML = articleHtml || '' ;
    const urls = new Set() ;
    for (const img of container.querySelectorAll('img')) {
      for (const u of [img.currentSrc, img.src, img.dataset?.src]) {
        if (u && u.startsWith('http')) urls.add(u) ;
      }
    }
    for (const a of container.querySelectorAll('a[href]')) {
      const u = a.href ;
      if (u && u.startsWith('http')) urls.add(u) ;
    }
    for (const v of container.querySelectorAll('video source[src], video[src], audio source[src], audio[src]')) {
      const u = v.src || v.getAttribute('src') ;
      if (u && u.startsWith('http')) urls.add(u) ;
    }
    return urls ;
  }

  // ---------- 미디어/링크 수집 ----------
  function pickLargestSrcset(img) {
    const srcset = img.getAttribute('srcset') ;
    if (!srcset) return null ;
    let best = null, bestW = 0 ;
    for (const part of srcset.split(',')) {
      const [url, desc] = part.trim().split(/\s+/) ;
      const w = desc?.endsWith('w') ? parseInt(desc, 10) : 0 ;
      if (url && w > bestW) { best = url; bestW = w ; }
    }
    return best ;
  }

  function collectImages() {
    const images = [] ;
    const seen = new Set() ;
    const add = (el, url, source) => {
      if (!url || !url.startsWith('http') || seen.has(url)) return ;
      seen.add(url) ;
      const rect = el.getBoundingClientRect() ;
      images.push({
        id: `i${images.length}`,
        url,
        source, // 'img' | 'bg' | 'poster'
        w: rect.width > 0 ? Math.round(rect.width) : 0,
        h: rect.height > 0 ? Math.round(rect.height) : 0,
        alt: el.alt || '',
        type: url.split('?')[0].split('.').pop()?.toLowerCase() || 'unknown',
      }) ;
    } ;
    for (const img of document.images) {
      add(img, pickLargestSrcset(img) || img.currentSrc || img.src || img.dataset?.src, 'img') ;
    }
    return images ;
  }

  function collectVideos() {
    const videos = [] ;
    const seen = new Set() ;
    const push = (el, url, kind) => {
      if (!url || !url.startsWith('http') || seen.has(url)) return ;
      seen.add(url) ;
      const lower = url.toLowerCase() ;
      videos.push({
        id: `v${videos.length}`,
        url,
        kind, // 'video' | 'source' | 'hls' | 'dash'
        type: lower.endsWith('.m3u8') ? 'hls' : lower.endsWith('.mpd') ? 'dash' : (url.split('?')[0].split('.').pop() || 'mp4').toLowerCase(),
        label: '',
        inArticle: false,
      }) ;
    } ;
    for (const v of document.querySelectorAll('video')) {
      push(v, v.currentSrc || v.src, 'video') ;
      for (const s of v.querySelectorAll('source[src]')) push(s, s.src, 'source') ;
    }
    return videos ;
  }

  function collectAudio() {
    const audios = [] ;
    const seen = new Set() ;
    for (const a of document.querySelectorAll('audio')) {
      const src = a.currentSrc || a.src ;
      if (src?.startsWith('http') && !seen.has(src)) {
        seen.add(src) ;
        audios.push({
          id: `a${audios.length}`,
          url: src,
          type: (src.split('?')[0].split('.').pop() || 'mp3').toLowerCase(),
          inArticle: false,
        }) ;
      }
      for (const s of a.querySelectorAll('source[src]')) {
        const u = s.src ;
        if (u?.startsWith('http') && !seen.has(u)) {
          seen.add(u) ;
          audios.push({ id: `a${audios.length}`, url: u, type: 'audio', inArticle: false }) ;
        }
      }
    }
    return audios ;
  }

  function collectLinks() {
    const links = [] ;
    const seen = new Set() ;
    const FILE_RE = /\.(pdf|zip|rar|7z|tar|gz|mp4|webm|mkv|mp3|wav|flac|xlsx?|docx?|pptx?|csv|json|xml)(\?|#|$)/i ;
    for (const a of document.querySelectorAll('a[href]')) {
      const url = a.href ;
      if (!url || !url.startsWith('http') || seen.has(url)) continue ;
      seen.add(url) ;
      const m = url.match(FILE_RE) ;
      links.push({
        id: `l${links.length}`,
        url,
        text: (a.textContent || '').trim().slice(0, 120),
        type: m ? m[1].toLowerCase() : 'html',
        inArticle: false,
      }) ;
    }
    return links ;
  }

  // ---------- HLS/DASH 후보: DOM 소스 + 선언된 <link> preload ----------
  function collectStreams() {
    const streams = [] ;
    const seen = new Set() ;
    const candidates = [
      ...document.querySelectorAll('video[src*=".m3u8"], video source[src*=".m3u8"], video[src*=".mpd"], video source[src*=".mpd"]'),
      ...document.querySelectorAll('link[rel="preload"][href*=".m3u8"], link[rel="preload"][href*=".mpd"]'),
    ] ;
    for (const el of candidates) {
      const url = el.src || el.href || el.getAttribute('src') || el.getAttribute('href') ;
      if (url?.startsWith('http') && !seen.has(url)) {
        seen.add(url) ;
        streams.push({
          id: `s${streams.length}`,
          url,
          protocol: url.toLowerCase().endsWith('.mpd') ? 'dash' : 'hls',
          qualities: [],
          inArticle: false,
        }) ;
      }
    }
    return streams ;
  }

  // ---------- 본문 배경 이미지 스캔 (성능 보호: 본문 컨테이너 한정) ----------
  function collectBgImages(articleContainer) {
    const out = [] ;
    if (!articleContainer) return out ;
    const bgRe = /url\(["']?([^"')]+)["']?\)/g ;
    const seen = new Set() ;
    for (const el of articleContainer.querySelectorAll('*')) {
      const bg = getComputedStyle(el).backgroundImage ;
      if (!bg || bg === 'none') continue ;
      let m ;
      while ((m = bgRe.exec(bg)) !== null) {
        const url = new URL(m[1], location.href).href ;
        if (url.startsWith('http') && !seen.has(url)) {
          seen.add(url) ;
          out.push({ id: `i${out.length}`, url, source: 'bg', w: 0, h: 0, alt: '', type: (url.split('?')[0].split('.').pop() || 'unknown').toLowerCase() }) ;
        }
      }
    }
    return out ;
  }

  // ---------- 실행 ----------
  function analyze() {
    const t0 = performance.now() ;
    const article = extractArticle() ;
    const articleUrls = collectArticleUrls(article?.content) ;

    const images = collectImages() ;
    const videos = collectVideos() ;
    const audios = collectAudio() ;
    const links = collectLinks() ;
    const streams = collectStreams() ;

    let articleContainer = null ;
    if (article?.content) {
      articleContainer = document.createElement('div') ;
      articleContainer.innerHTML = article.content ;
    }
    const bgImages = collectBgImages(articleContainer) ;
    images.push(...bgImages) ;

    const mark = (item) => {
      item.inArticle = articleUrls.has(item.url) || (item.source === 'bg') ;
      return item ;
    } ;
    images.forEach(mark) ;
    videos.forEach(mark) ;
    audios.forEach(mark) ;
    links.forEach(mark) ;
    streams.forEach(mark) ;

    const perf = performance.now() - t0 ;
    const result = {
      url: location.href,
      title: document.title,
      analyzedAt: Date.now(),
      article: article
        ? { found: true, title: article.title, byline: article.byline || '', excerpt: (article.excerpt || '').slice(0, 200), bodyTextLen: article.textContent?.length || 0 }
        : { found: false },
      media: { images, videos, audios, streams },
      links,
      stats: {
        totalImages: images.length,
        totalVideos: videos.length,
        totalAudios: audios.length,
        totalStreams: streams.length,
        totalLinks: links.length,
        articleFound: Boolean(article),
      },
    } ;

    // 크기 가드: 1MB 초과 시 링크/이미지 절단
    if (JSON.stringify(result).length > 1_000_000) {
      result.links = result.links.slice(0, 2000) ;
      result.media.images = result.media.images.slice(0, 2000) ;
      BGLogger?.warn?.('EXTRACT', '결과 1MB 초과 — 샘플링 적용') ;
    }
    DebugLogger.info(`[EXTRACT] 분석 완료 (${perf.toFixed(1)}ms, img=${images.length} vid=${videos.length} links=${links.length} article=${Boolean(article)})`) ;
    DebugLogger.perf('분석 소요시간', perf) ;
    return result ;
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === 'pk.analyze.page') {
      DebugLogger.info('[EXTRACT] 분석 시작', { url: location.href }) ;
      try {
        const result = analyze() ;
        DebugLogger.feature('EXTRACT', '분석 결과 반환', result.stats) ;
        sendResponse({ ok: true, data: result }) ;
      } catch (e) {
        DebugLogger.error('[EXTRACT] 분석 실패', `${e.name}: ${e.message}`, { code: 'E-CHR-NET-1001' }) ;
        sendResponse({ ok: false, error: { code: 'E-CHR-NET-1001', message: '페이지 분석에 실패했습니다.' } }) ;
      }
      return false ;
    }
    return false ;
  }) ;

  const t1 = performance.now() ;
  DebugLogger.feature('EXTRACT', `extractor 로드 완료 (${(t1 - T0).toFixed(1)}ms)`) ;
})() ;