// sidepanel/panel.js — 사이드 패널 메인 로직 (분류 탭 + 검색/필터 + 선택 + 다운로드)

import { MSG } from '../shared/messages.js' ;

const $ = (id) => document.getElementById(id) ;

let analysis = null ;
let currentTab = 'all' ;
let selection = new Set() ;

// ---------- 분석 실행 ----------
async function analyze() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }) ;
  if (!tab?.id) return ;
  DebugLogger.info('[PANEL] 분석 시작', { url: tab.url || '' }) ;
  try {
    const resp = await chrome.tabs.sendMessage(tab.id, { type: MSG.ANALYZE_PAGE }) ;
    if (resp?.ok) {
      analysis = resp.data ;
      selection = new Set() ;
      render() ;
      DebugLogger.feature('PANEL', '분석 표시됨', analysis.stats) ;
    } else {
      DebugLogger.warn('[PANEL] 분석 실패 (콘텐츠 스크립트 없음)', { code: 'E-CHR-NET-1001' }) ;
      toast('분석 실패: 콘텐츠 스크립트가 없습니다. 페이지를 새로고침 후 시도하세요.') ;
    }
  } catch (e) {
    DebugLogger.error('[PANEL] 분석 실패', `${e.name}: ${e.message}`, { code: 'E-CHR-NET-1001' }) ;
    toast('분석 실패: 페이지를 새로고침 후 시도하세요.') ;
  }
}

// ---------- 아이템 구성 ----------
function allItems() {
  if (!analysis) return [] ;
  return [
    ...analysis.media.images.map((i) => ({ ...i, cat: 'images', size: i.size || 0 })),
    ...analysis.media.videos.map((v) => ({ ...v, cat: 'videos', size: 0 })),
    ...analysis.media.audios.map((a) => ({ ...a, cat: 'audios', size: 0 })),
    ...analysis.media.streams.map((s) => ({ ...s, cat: 'streams', size: 0 })),
    ...analysis.links.map((l) => ({ ...l, cat: 'links', size: 0 })),
  ] ;
}

function tabItems() {
  const q = $('pk-search').value.trim().toLowerCase() ;
  const articleOnly = $('pk-article-only').checked ;
  const type = $('pk-type-filter').value ;
  return allItems().filter((it) => {
    if (currentTab !== 'all' && it.cat !== currentTab) return false ;
    if (articleOnly && !it.inArticle) return false ;
    if (type && it.type !== type) return false ;
    if (q && !(it.url || '').toLowerCase().includes(q) && !(it.text || '').toLowerCase().includes(q)) return false ;
    return true ;
  }) ;
}

// ---------- 렌더링 ----------
function formatSize(bytes) {
  if (!bytes) return '' ;
  return bytes > 1024 * 1024 ? `${(bytes / 1024 / 1024).toFixed(1)}MB` : `${Math.max(1, Math.round(bytes / 1024))}KB` ;
}

function formatDim(it) {
  const dim = it.w && it.h ? `${it.w}×${it.h}` : '' ;
  return [dim, formatSize(it.size), it.type].filter(Boolean).join(' · ') ;
}

function thumbFor(it) {
  if (it.cat === 'images' && it.url.startsWith('http')) {
    return `<div class="pk-thumb" style="background-image:url('${CSS.escape(it.url)}')"></div>` ;
  }
  const emoji = { images: '🖼', videos: '🎬', audios: '🎵', streams: '📡', links: '🔗' }[it.cat] || '📄' ;
  return `<div class="pk-thumb">${emoji}</div>` ;
}

function render() {
  if (!analysis) {
    $('pk-empty').hidden = false ;
    $('pk-list').innerHTML = '' ;
    return ;
  }
  $('pk-empty').hidden = true ;
  $('pk-page-title').textContent = analysis.title || analysis.url ;

  // 카운트 배지
  const s = analysis.stats ;
  $('pk-c-all').textContent = allItems().length ;
  $('pk-c-images').textContent = s.totalImages ;
  $('pk-c-videos').textContent = s.totalVideos ;
  $('pk-c-audios').textContent = s.totalAudios ;
  $('pk-c-streams').textContent = s.totalStreams ;
  $('pk-c-links').textContent = s.totalLinks ;

  const items = tabItems() ;
  $('pk-list').innerHTML = items.slice(0, 500).map((it) => `
    <label class="pk-item ${it.inArticle ? '' : 'is-out'}" data-id="${it.id}">
      ${thumbFor(it)}
      <div class="pk-info">
        <div class="pk-name">${CSS.escape(it.text || it.url)}</div>
        <div class="pk-meta">${formatDim(it)}</div>
      </div>
      <span class="pk-tag">${it.inArticle ? '본문' : '외부'}</span>
      <input type="checkbox" data-id="${it.id}" ${selection.has(it.id) ? 'checked' : ''} />
    </label>`).join('') + (items.length > 500 ? '<div class="pk-empty">500개까지만 표시됩니다.</div>' : '') ;

  updateSelectionUI() ;
}

function updateSelectionUI() {
  const items = allItems().filter((it) => selection.has(it.id)) ;
  $('pk-selected-count').textContent = items.length ;
  $('pk-selected-size').textContent = formatSize(items.reduce((a, b) => a + (b.size || 0), 0)) || '0B' ;
  $('pk-download').disabled = items.length === 0 ;
}

function toast(msg) {
  const el = $('pk-toast') ;
  el.textContent = msg ;
  el.hidden = false ;
  clearTimeout(el._t) ;
  el._t = setTimeout(() => { el.hidden = true ; }, 2500) ;
}

// ---------- 이벤트 ----------
$('pk-reload').addEventListener('click', analyze) ;
$('pk-search').addEventListener('input', render) ;
$('pk-article-only').addEventListener('change', render) ;
$('pk-type-filter').addEventListener('change', render) ;
document.querySelectorAll('.pk-tab').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.pk-tab').forEach((b) => b.classList.remove('is-active')) ;
    btn.classList.add('is-active') ;
    currentTab = btn.dataset.tab ;
    $('pk-type-filter').hidden = !(currentTab === 'images' || currentTab === 'links') ;
    DebugLogger.debug('[PANEL] 탭 전환', { tab: currentTab }) ;
    render() ;
  }) ;
}) ;

$('pk-list').addEventListener('click', (e) => {
  const box = e.target.closest('input[type="checkbox"]') ;
  if (!box) return ;
  const id = box.dataset.id ;
  if (box.checked) selection.add(id) ;
  else selection.delete(id) ;
  updateSelectionUI() ;
}) ;

$('pk-download').addEventListener('click', async () => {
  const items = allItems().filter((it) => selection.has(it.id)) ;
  DebugLogger.feature('PANEL', `다운로드 시작 요청 (${items.length}건)`, { urls: items.slice(0, 5).map((i) => i.url) }) ;
  const resp = await chrome.runtime.sendMessage({ type: MSG.DOWNLOAD_START, payload: { items } }) ;
  if (resp?.ok) {
    DebugLogger.feature('PANEL', `다운로드 시작됨 (${items.length}건)`) ;
    toast(`다운로드 시작 (${items.length}건)`) ;
  } else {
    DebugLogger.error('[PANEL] 다운로드 시작 실패', resp?.error?.message, resp?.error, { code: 'E-CHR-DL-1001' }) ;
    toast(resp?.error?.message || '다운로드 실패') ;
  }
}) ;

// 다운로드 진행 수신 (BG broadcast 대신 session 폴링)
chrome.storage.session.onChanged.addListener((changes) => {
  if (changes.downloadJobs) {
    const jobs = changes.downloadJobs.newValue || [] ;
    const active = jobs.filter((j) => j.state === 'active') ;
    $('pk-reload').textContent = active.length ? `${active.length}⬇` : '⟳' ;
  }
}) ;

// 초기 분석
DebugLogger.feature('PANEL', '사이드 패널 로드 완료') ;
analyze() ;