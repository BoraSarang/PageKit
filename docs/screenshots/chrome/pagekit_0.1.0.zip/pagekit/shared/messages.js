// shared/messages.js — BG↔content↔UI 메시지 타입/상수
// docs/chrome/MESSAGING.md 규약 참조

export const MSG = {
  ANALYZE_PAGE: 'pk.analyze.page',
  ANALYZE_PAGE_RESULT: 'pk.analyze.result',
  ENSURE_INJECTED: 'pk.inject.ensure',
  OPEN_SIDE_PANEL: 'pk.ui.openPanel',
  DOWNLOAD_START: 'pk.dl.start',
  DOWNLOAD_PROGRESS: 'pk.dl.progress',
  DOWNLOAD_STATE: 'pk.dl.state',
  DOWNLOAD_CANCEL: 'pk.dl.cancel',
  HIGHLIGHT_TOGGLE: 'pk.ui.highlight',
  FLOAT_BUTTON_READY: 'pk.content.floatReady',
  SETTINGS_GET: 'pk.settings.get',
  SETTINGS_SET: 'pk.settings.set',
  UNLOCK_TOGGLE: 'pk.unlock.toggle',
} ;

export const PANEL_SOURCES = ['icon', 'context', 'shortcut', 'popup', 'float'] ;

export const MSG_OK = { ok: true } ;
export function msgOk(data) {
  return data === undefined ? { ok: true } : { ok: true, data } ;
}
export function msgErr(code, message) {
  return { ok: false, error: { code, message } } ;
}